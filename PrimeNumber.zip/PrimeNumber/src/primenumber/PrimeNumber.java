/*
 Prompts user for two positive integers, displays all prime numbers between them
 April 23, 2017
 Brett Castellano
 */
package primenumber;

import java.util.Scanner;

/**
 *
 * @author Brett
 */
public class PrimeNumber {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int firstNumber, secondNumber;  //range for prime numbers
        int divisor, i;   

        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a positive Integer greater than 1: ");    //prompt for lower number
        firstNumber = input.nextInt();
        while (firstNumber <= 1) {
            System.out.println("Please enter a positive Integer greater than 1: ");
            firstNumber = input.nextInt();
        }
        System.out.println("Please enter a higher positive Integer: ");      //prompt for higher number
        secondNumber = input.nextInt();

        System.out.println("The prime numbers between " + firstNumber + " and " + secondNumber + " are: ");     //sentence for prime numbers

        for (i = firstNumber; i <= secondNumber; i++) {     //create range using users parameters
            divisor = 2;
            
            while (i % divisor != 0) {
                divisor++;
            }
            
            if (divisor == i) {
                System.out.println(i);
            }
        }
                        
    }
}